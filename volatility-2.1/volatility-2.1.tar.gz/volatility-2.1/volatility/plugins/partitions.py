# Volatility
#
# Authors:
# Michael Hale Ligh <michael.ligh@mnin.org>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at
# your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
#

import sys
import volatility.utils as utils
import volatility.commands as commands
import volatility.scan as scan
import volatility.obj as obj
import volatility.plugins.netscan as netscan
import volatility.debug as debug
import volatility.plugins.common as common

#--------------------------------------------------------------------------------
# pool scanners 
#--------------------------------------------------------------------------------

class PoolScanPartitionTable(scan.PoolScanner):
    """Scanner for tcpip partition tables"""

    def object_offset(self, found, address_space):
        return found + (address_space.profile.get_obj_size("_POOL_HEADER") -
                address_space.profile.get_obj_offset("_POOL_HEADER", "PoolTag"))

    checks = [ ('PoolTagCheck', dict(tag = "TcPt")),
               # The size of the partition table is a multiple of _PARTITION
               # size and the number of CPUs. On single core systems, there 
               # will be only one _PARTITION. The smallest size of a partition
               # across the various Vista/2008/7 x86/x64 profiles we support
               # is 0x24, thus it becomes our minimum requirement for pool size. 
               ('CheckPoolSize', dict(condition = lambda x: x >= 0x24)),
               # The _PARTITION table is always in non-paged memory. There is 
               # no need to search paged or free pools. 
               ('CheckPoolType', dict(non_paged = True)),
               ('CheckPoolIndex', dict(value = 0)),
               ]

#--------------------------------------------------------------------------------
# profile modifications 
#--------------------------------------------------------------------------------

class Vista2008HashTable86(obj.ProfileModification):
    """Applies to Vista and 2008 x86"""

    before = ['WindowsVTypes']

    conditions = {'os': lambda x: x == 'windows',
                  'memory_model': lambda x: x == '32bit',
                  'major': lambda x : x == 6,
                  'minor': lambda x : x == 0}

    def modification(self, profile):
        profile.vtypes.update({
            '_RTL_DYNAMIC_HASH_TABLE': [ None, {
                'TableSize' : [ 8, ['unsigned long']],
                'Directory': [ 0x30, ['pointer',
                    ['array', lambda x: x.TableSize, ['_LIST_ENTRY']]]],
            }],
            '_TCB_HASH_TABLES': [ None, {
                'Tcb': [ 0, ['_RTL_DYNAMIC_HASH_TABLE']],
                'TcbTimeWait': [ 0x230, ['_RTL_DYNAMIC_HASH_TABLE']],
                'TcbSyn': [ 0x690, ['_RTL_DYNAMIC_HASH_TABLE']],
            }],
            '_PARTITION': [ 0x24, {
                'HashTableAllocation': [ 0, ['pointer', ['void']]], # TcHT pool
                'HashTables': [ 4, ['pointer', ['_TCB_HASH_TABLES']]],
            }]})

class Vista2008HashTable64(obj.ProfileModification):
    """Applies to Vista and 2008 x64"""

    before = ['WindowsVTypes']

    conditions = {'os': lambda x: x == 'windows',
                  'memory_model': lambda x: x == '64bit',
                  'major': lambda x : x == 6,
                  'minor': lambda x : x == 0}

    def modification(self, profile):
        profile.vtypes.update({
            '_RTL_DYNAMIC_HASH_TABLE': [ None, {
                'TableSize' : [ 8, ['unsigned long']],
                'Directory': [ 0x38, ['pointer',
                    ['array', lambda x: x.TableSize, ['_LIST_ENTRY']]]],
            }],
            '_TCB_HASH_TABLES': [ None, {
                'Tcb': [ 0, ['_RTL_DYNAMIC_HASH_TABLE']],
                'TcbTimeWait': [ 0x438, ['_RTL_DYNAMIC_HASH_TABLE']],
                'TcbSyn': [ 0xca8, ['_RTL_DYNAMIC_HASH_TABLE']],
            }],
            '_PARTITION': [ 0x40, {
                'HashTableAllocation': [ 0, ['pointer', ['void']]],
                'HashTables': [ 8, ['pointer', ['_TCB_HASH_TABLES']]],
            }]})

class Win7HashTable(obj.ProfileModification):
    """Applies to Windows 7 x86 and x64"""

    before = ['WindowsVTypes']

    conditions = {'os': lambda x: x == 'windows',
                  'major': lambda x : x == 6,
                  'minor': lambda x : x == 1}

    def modification(self, profile):
        # PDB already defines this structure but we overlay its 
        # Directory member instead of using pointer void. 
        profile.merge_overlay({
            '_RTL_DYNAMIC_HASH_TABLE': [ None, {
                'Directory': [ None, ['pointer',
                    ['array', lambda x: x.TableSize, ['_LIST_ENTRY']]]],
            }]})
        profile.vtypes.update({
            '_TCB_HASH_TABLES': [ None, {
                'Tcb': [ 0, ['_RTL_DYNAMIC_HASH_TABLE']],
                'TcbTimeWait': [ 0x24, ['_RTL_DYNAMIC_HASH_TABLE']],
                'TcbSyn': [ 0x6c, ['_RTL_DYNAMIC_HASH_TABLE']],
            }],
            '_PARTITION': [ 0x48, {
                'HashTableAllocation': [ 0, ['pointer', ['void']]],
                'HashTables': [ 4, ['pointer', ['_TCB_HASH_TABLES']]],
            }]})

class PartitionModifications(obj.ProfileModification):
    """Applies to all Vista/2008/7 x86 and x64"""

    conditions = {'os': lambda x: x == 'windows',
                  'major': lambda x : x == 6,
                  'minor': lambda x : x >= 0}

    def modification(self, profile):
        profile.vtypes.update({
            # Pointed to by tcpip!PartitionTable
            '_PARTITION_TABLE': [ None, {
                # The array size varies by processor count. See 
                # the comments for PoolScanPartitionTable and the 
                # _PARTITION_TABLE object class. 
                'Partitions' : [ 0, ['array', 1, ['_PARTITION']]],
            }]})

        profile.object_classes.update({
            '_PARTITION_TABLE': _PARTITION_TABLE,
            '_PARTITION': _PARTITION,
            '_TCP_SYN_ENDPOINT': _TCP_SYN_ENDPOINT,
            '_TCP_TIMEWAIT_ENDPOINT': _TCP_TIMEWAIT_ENDPOINT,
            })

class Win7Partitionx64(obj.ProfileModification):
    """Applies to Windows 7 x64"""

    before = ['Win7HashTable']

    conditions = {'os': lambda x: x == 'windows',
                  'memory_model': lambda x: x == '64bit',
                  'major': lambda x : x == 6,
                  'minor': lambda x : x == 1}

    def modification(self, profile):
        profile.merge_overlay({
            '_TCB_HASH_TABLES': [ None, {
                'TcbTimeWait': [ 0x28, ['_RTL_DYNAMIC_HASH_TABLE']],
                'TcbSyn': [ 0x78, ['_RTL_DYNAMIC_HASH_TABLE']],
            }],
            '_PARTITION': [ 0x78, {
                'HashTables': [ 8, ['pointer', ['_TCB_HASH_TABLES']]],
            }]})

#--------------------------------------------------------------------------------
# object classes
#--------------------------------------------------------------------------------

class _PARTITION_TABLE(obj.CType):
    """Class for TCPIP partition tables"""

    def is_valid(self):
        """Override the standard is_valid() with an extra check. 
        This verifies our partition table with HashTableMagic"""

        return (obj.CType.is_valid(self) and
                    (self.HashTables.v() - self.HashTableAllocation.v() !=
                    obj.VolMagic(self.obj_vm).HashTableMagic.v()))

    @property
    def Partitions(self):
        """The number of _PARTITION objects in a _PARTITION_TABLE
        is a multiple of the number of CPUs on the system. Since 
        there's no good way to do that calculation for a vtype array
        size, we override the vtype definition with a property and 
        calculate it in reverse - by dividing the _PARTITION_TABLE 
        size by the size of a _PARTITION"""

        # Size of a pool header
        pool_header_size = self.obj_vm.profile.get_obj_size("_POOL_HEADER")

        # The pool alignment 
        pool_align = obj.VolMagic(self.obj_vm).PoolAlignment.v()

        # Get this object's pool header 
        pool_header = obj.Object("_POOL_HEADER", offset = self.obj_offset -
            pool_header_size, vm = self.obj_vm)

        # Determine the pool size by multiplying by alignment 
        pool_size = (pool_header.BlockSize * pool_align)

        # The size of the objects this pool contains 
        part_size = common.pool_align(self.obj_vm, "_PARTITION", pool_align)

        sys.stdout.write("pool_size {0}, part_size {1}\n".format(
                pool_size, part_size))

        # If the pool size isn't evenly divisible by the size of
        # the objects it contains, something is wrong. 
        if (pool_size % part_size) % pool_align != 0:
            return obj.NoneObject("Bad alignment")

        # A collection of partitions 
        parts = obj.Object("Array", targetType = "_PARTITION",
                    count = pool_size / part_size,
                    offset = self.m('Partitions').obj_offset,
                    vm = self.obj_vm, native_vm = self.obj_native_vm)

        return parts

class _PARTITION(obj.CType):
    """Class for partitions"""

    def _hash_enumerator(self, hash_table, vol_type):
        """Enumerate TCP endpoints from a hash table. This function 
        combines the work of two APIs from the tcpip.sys drivers:

        * RtlInitWeakEnumerationHashTable
        * RtlWeaklyEnumerateEntryHashTable

        @param hash_table: the member of _PARTITION to enumerate

        @param vol_type: the type of structure found in the hash 
        """

        if not hash_table:
            return

        # The directory is a pointer to an array of _LIST_ENTRYs
        lists = hash_table.Directory.dereference()

        for i, list in enumerate(lists):
            # Ignore empty lists
            if list.obj_offset == list.Flink.v() == list.Blink.v():
                continue
            for entry in list.list_of_type(vol_type, "ListEntry"):
                yield entry

    def get_tcb(self):
        """Enumerate all objects from the Tcb hash table"""
        return self._hash_enumerator(
            self.HashTables.dereference().Tcb,
            "_TCP_ENDPOINT")

    def get_tcbsyn(self):
        """Enumerate all objects in the SYN state"""
        return self._hash_enumerator(
            self.HashTables.dereference().TcbSyn,
            "_TCP_SYN_ENDPOINT")

    def get_tcbtimewait(self):
        """Enumerate all objects in the TIME_WAIT state"""
        return self._hash_enumerator(
            self.HashTables.dereference().TcbTimeWait,
            "_TCP_TIMEWAIT_ENDPOINT")

class _TCP_SYN_ENDPOINT(netscan._TCP_ENDPOINT):

    @property
    def LocalAddress(self):
        inaddr = self.LocalAddr.dereference().\
                            pData.dereference().dereference()

        return self._ipv4_or_ipv6(inaddr)

    @property
    def RemoteAddress(self):
        inaddr = self.m('RemoteAddress').dereference()
        return self._ipv4_or_ipv6(inaddr)

    @property
    def State(self):
        """By nature, anything in this structure is in the
        SYN state. This structure has no State member, so 
        we fake it with a property"""
        return "SYN_SENT/SYN_RECV"

    @property
    def Owner(self):
        return self.m('Owner').dereference().Process.dereference()

class _TCP_TIMEWAIT_ENDPOINT(_TCP_SYN_ENDPOINT):

    @property
    def State(self):
        """By nature, anything in this structure is in the
        TIME_WAIT state. This structure has no State member,
        so we fake it with a property"""
        return "TIME_WAIT"

    @property
    def Owner(self):
        return obj.NoneObject("")

#--------------------------------------------------------------------------------
# volatility magic  
#--------------------------------------------------------------------------------

class HashTableMagic(obj.ProfileModification):
    """Add some magic to this sorcery"""

    conditions = {'os': lambda x: x == 'windows',
                  'major': lambda x : x == 6}

    def modification(self, profile):

        m = profile.metadata

        version = (m.get('major', 0), m.get('minor', 0), m.get('build', 0))

        # In tcpip!TcpStartPartitionModule, the driver allocates a 
        # block of memory and assigns it to HashTableAllocation. 
        # Then it assigns an address within that allocation to 
        # HashTables. The offset to HashTables from the base 
        # of the main allocation is 0x40 for Vista SP0 x86/x64. 
        # All others use 0x140. That becomes our magic. 

        if version == (6, 0, 6000):
            hash_table_magic = 0x40
        else:
            hash_table_magic = 0x140

        profile.merge_overlay({'VOLATILITY_MAGIC': [ None, {
                'HashTableMagic': [ 0,
                    ['VolatilityMagic', dict(value = hash_table_magic)]]
            }]})

#--------------------------------------------------------------------------------
# connscanx plugin  
#--------------------------------------------------------------------------------

class ConnScanX(commands.Command):
    """Vista/2008/7 Connections via Partitions and Dynamic Hash Tables"""

    def __init__(self, config, *args, **kwargs):
        commands.Command.__init__(self, config, *args, **kwargs)

        config.add_option("PHYSICAL-OFFSET", short_option = 'P',
                          default = False,
                          help = "Physical Offset", action = "store_true")

    def calculate(self):

        # Virtual kernel space for dereferencing pointers
        kernel_space = utils.load_as(self._config)

        # Physical space for scanning 
        flat_space = utils.load_as(self._config, astype = 'physical')

        # Scan for the partition table at tcpip!PartitionTable
        for offset in PoolScanPartitionTable().scan(flat_space):

            partition_table = obj.Object('_PARTITION_TABLE',
                offset = offset, vm = flat_space,
                native_vm = kernel_space)

            sys.stdout.write("tcpip!PartitionTable at {0:#x} (P)\n".format(
                partition_table.obj_offset))

            for i, part in enumerate(partition_table.Partitions):

                sys.stdout.write("Partition {0} at {1:#x} Valid: {2}\n".format(
                    i, part.obj_offset, part.is_valid()))

                # Sanity check the partition with our magic
                if not part.is_valid():
                    continue

                sys.stdout.write("Tcb at {0:#x} Directory {1:#x} Size: {2:#x}\n".format(
                    part.HashTables.dereference().Tcb.obj_offset,
                    part.HashTables.dereference().Tcb.Directory.v(),
                    part.HashTables.dereference().Tcb.TableSize,
                    ))

                sys.stdout.write("TcbSyn at {0:#x} Directory {1:#x} Size: {2:#x}\n".format(
                    part.HashTables.dereference().TcbSyn.obj_offset,
                    part.HashTables.dereference().TcbSyn.Directory.v(),
                    part.HashTables.dereference().TcbSyn.TableSize,
                    ))

                sys.stdout.write("TcbTimeWait at {0:#x} Directory {1:#x} {2:#x}\n".format(
                    part.HashTables.dereference().TcbTimeWait.obj_offset,
                    part.HashTables.dereference().TcbTimeWait.Directory.v(),
                    part.HashTables.dereference().TcbTimeWait.TableSize,
                    ))

                # TCB endpoints 
                for entry in part.get_tcb():
                    yield entry

                # TCB SYN 
                for entry in part.get_tcbsyn():
                    yield entry

                # TCB TIME WAIT 
                for entry in part.get_tcbtimewait():
                    yield entry

    def render_text(self, outfd, data):

        outfd.write("{0:<20} {1:<12} {2:<24} {3:<24} {4:<8} {5}\n".format(
            "Object", "State", "Local", "Remote", "Pid", "Process"))

        # If the same _PARTITION exists in two places, then its 
        # hash bucket contains all the same objects. This filter
        # prevents us from showing duplicates. 
        seen_entries = []

        for tcpe in data:

            if tcpe.obj_offset in seen_entries:
                continue
            seen_entries.append(tcpe.obj_offset)

            # Print the physical offset instead of virtual. Useful if
            # you want to compare with netscan output. 
            if not self._config.PHYSICAL_OFFSET:
                offset = tcpe.obj_offset
            else:
                offset = tcpe.obj_vm.vtop(tcpe.obj_offset)

            local_endpoint = "{0}:{1}".format(tcpe.LocalAddress, tcpe.LocalPort)
            remote_endpoint = "{0}:{1}".format(tcpe.RemoteAddress, tcpe.RemotePort)

            outfd.write("{0:<#20x} {1:<12} {2:<24} {3:<24} {4:<8} {5}\n".format(
                offset, tcpe.State, local_endpoint, remote_endpoint,
                tcpe.Owner.UniqueProcessId, tcpe.Owner.ImageFileName
                ))

